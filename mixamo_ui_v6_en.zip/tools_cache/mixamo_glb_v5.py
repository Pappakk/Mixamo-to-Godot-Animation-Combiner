
import bpy
import sys
import os
import traceback


def arg_after(flag, default=None):
    argv = sys.argv
    if '--' in argv:
        argv = argv[argv.index('--') + 1:]
    else:
        argv = []
    if flag in argv:
        idx = argv.index(flag)
        if idx + 1 < len(argv):
            return argv[idx + 1]
    return default


def all_after(flag):
    argv = sys.argv
    if '--' in argv:
        argv = argv[argv.index('--') + 1:]
    else:
        argv = []
    if flag not in argv:
        return []
    idx = argv.index(flag) + 1
    values = []
    while idx < len(argv) and not argv[idx].startswith('--'):
        values.append(argv[idx])
        idx += 1
    return values


def clear_scene():
    bpy.ops.object.select_all(action='SELECT')
    bpy.ops.object.delete(use_global=False)
    for block in bpy.data.meshes:
        if block.users == 0:
            bpy.data.meshes.remove(block)
    for block in bpy.data.armatures:
        if block.users == 0:
            bpy.data.armatures.remove(block)
    for block in bpy.data.materials:
        if block.users == 0:
            bpy.data.materials.remove(block)
    for block in bpy.data.images:
        if block.users == 0:
            bpy.data.images.remove(block)


def import_fbx(filepath):
    before = set(bpy.data.objects)
    bpy.ops.import_scene.fbx(filepath=filepath, automatic_bone_orientation=True)
    after = set(bpy.data.objects)
    new_objs = list(after - before)
    return new_objs


def find_base_armature(objects):
    for obj in objects:
        if obj.type == 'ARMATURE':
            return obj
    for obj in bpy.data.objects:
        if obj.type == 'ARMATURE':
            return obj
    return None


def find_skinned_meshes(objects, armature):
    meshes = [o for o in objects if o.type == 'MESH']
    if meshes:
        return meshes
    result = []
    for obj in bpy.data.objects:
        if obj.type == 'MESH':
            for mod in obj.modifiers:
                if mod.type == 'ARMATURE' and mod.object == armature:
                    result.append(obj)
                    break
    return result


def set_active_action_name(action, wanted_name):
    if action is None:
        return None
    clean = os.path.splitext(os.path.basename(wanted_name))[0]
    action.name = clean
    return action


def append_animation_to_base(base_armature, anim_fbx):
    imported = import_fbx(anim_fbx)
    imported_armature = next((o for o in imported if o.type == 'ARMATURE'), None)
    imported_meshes = [o for o in imported if o.type == 'MESH']
    action = None
    if imported_armature and imported_armature.animation_data and imported_armature.animation_data.action:
        action = imported_armature.animation_data.action
    else:
        for act in bpy.data.actions:
            if os.path.splitext(os.path.basename(anim_fbx))[0].lower() in act.name.lower():
                action = act
                break
    if action is None:
        raise RuntimeError(f'Ingen action hittades i animationsfilen: {anim_fbx}')
    set_active_action_name(action, anim_fbx)
    if base_armature.animation_data is None:
        base_armature.animation_data_create()
    # Leave actions in datablock list so exporter can include them.
    base_armature.animation_data.action = action
    # Remove imported helper objects but keep action datablock.
    bpy.ops.object.select_all(action='DESELECT')
    for obj in imported_meshes:
        obj.select_set(True)
    if imported_armature:
        imported_armature.select_set(True)
    bpy.ops.object.delete(use_global=False)


def load_image(image_path):
    try:
        return bpy.data.images.load(image_path, check_existing=True)
    except Exception as exc:
        raise RuntimeError(f'Kunde inte ladda texturbilden: {image_path} | {exc}')


def ensure_material_with_texture(obj, image):
    mat = obj.active_material
    if mat is None:
        mat = bpy.data.materials.new(name=f'{obj.name}_Mat')
        if obj.data.materials:
            obj.data.materials[0] = mat
        else:
            obj.data.materials.append(mat)
    mat.use_nodes = True
    nt = mat.node_tree
    nodes = nt.nodes
    links = nt.links
    for node in list(nodes):
        if node.type not in {'OUTPUT_MATERIAL', 'BSDF_PRINCIPLED'}:
            nodes.remove(node)
    output = next((n for n in nodes if n.type == 'OUTPUT_MATERIAL'), None)
    if output is None:
        output = nodes.new('ShaderNodeOutputMaterial')
        output.location = (300, 0)
    bsdf = next((n for n in nodes if n.type == 'BSDF_PRINCIPLED'), None)
    if bsdf is None:
        bsdf = nodes.new('ShaderNodeBsdfPrincipled')
        bsdf.location = (0, 0)
    image_node = nodes.new('ShaderNodeTexImage')
    image_node.image = image
    image_node.location = (-350, 0)
    # Clear conflicting links on base color
    while bsdf.inputs['Base Color'].links:
        links.remove(bsdf.inputs['Base Color'].links[0])
    if not bsdf.outputs['BSDF'].links:
        links.new(bsdf.outputs['BSDF'], output.inputs['Surface'])
    links.new(image_node.outputs['Color'], bsdf.inputs['Base Color'])


def apply_texture(meshes, texture_path):
    if not texture_path:
        return 'Ingen separat textur vald.'
    image = load_image(texture_path)
    for obj in meshes:
        ensure_material_with_texture(obj, image)
    return f'Textur applicerad på {len(meshes)} mesh-objekt.'


def export_glb(output_path):
    # Export all actions for the armature/scene.
    kwargs = dict(
        filepath=output_path,
        export_format='GLB',
        export_yup=True,
        export_apply=False,
        export_texcoords=True,
        export_normals=True,
        export_tangents=False,
        export_materials='EXPORT',
        export_colors=True,
        export_cameras=False,
        export_extras=False,
        export_skins=True,
        export_animations=True,
        export_animation_mode='ACTIONS',
        export_nla_strips=False,
        export_optimize_animation_size=False,
        export_morph=False,
        export_image_format='AUTO'
    )
    bpy.ops.export_scene.gltf(**kwargs)


def main():
    model_path = arg_after('--model')
    output_path = arg_after('--output')
    texture_path = arg_after('--texture', '')
    animation_paths = all_after('--animations')

    if not model_path or not output_path or not animation_paths:
        raise RuntimeError('Saknar --model, --animations eller --output')

    clear_scene()
    base_imported = import_fbx(model_path)
    base_armature = find_base_armature(base_imported)
    if base_armature is None:
        raise RuntimeError('Ingen armature hittades i modellfilen.')
    base_meshes = find_skinned_meshes(base_imported, base_armature)
    if not base_meshes:
        raise RuntimeError('Ingen mesh hittades i modellfilen.')

    if base_armature.animation_data is None:
        base_armature.animation_data_create()

    imported_action_names = []
    for anim in animation_paths:
        append_animation_to_base(base_armature, anim)
        imported_action_names.append(os.path.splitext(os.path.basename(anim))[0])

    texture_note = apply_texture(base_meshes, texture_path)

    export_glb(output_path)

    print('DONE')
    print('Base armature:', base_armature.name)
    print('Meshes:', ', '.join([m.name for m in base_meshes]))
    print('Actions:', ', '.join(imported_action_names))
    print(texture_note)
    print('Output:', output_path)


try:
    main()
except Exception as exc:
    print('ERROR:', exc)
    traceback.print_exc()
    raise
