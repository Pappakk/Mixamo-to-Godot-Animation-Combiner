const statusBox = document.getElementById('statusBox');
const resultState = document.getElementById('resultState');
const commandPreview = document.getElementById('commandPreview');
const stdoutBox = document.getElementById('stdoutBox');
const stderrBox = document.getElementById('stderrBox');
const runForm = document.getElementById('runForm');
const runBtn = document.getElementById('runBtn');
const fillExampleBtn = document.getElementById('fillExampleBtn');
const downloadWrap = document.getElementById('downloadWrap');
const downloadLink = document.getElementById('downloadLink');
const modelInput = document.getElementById('modelFile');
const textureInput = document.getElementById('textureFile');
const animationsInput = document.getElementById('animationFiles');
const modelName = document.getElementById('modelName');
const textureName = document.getElementById('textureName');
const animationsName = document.getElementById('animationsName');

function setStatus(el, type, text) {
  el.className = `status ${type}`;
  el.textContent = text;
}

function setFileLabel(input, el, multiple = false) {
  const files = Array.from(input.files || []);
  if (!files.length) {
    el.textContent = 'No file selected';
    return;
  }
  if (multiple) {
    el.textContent = `${files.length} files selected: ${files.map(f => f.name).join(', ')}`;
    return;
  }
  el.textContent = files[0].name;
}

async function loadStatus() {
  try {
    const response = await fetch('/api/status');
    const data = await response.json();
    if (!response.ok || !data.ok) throw new Error(data.error || 'Could not read status.');
    const parts = [
      `Blender: ${data.blenderPath || 'not found yet'}`,
      `Wrapper script: ${data.wrapperCached ? 'ready' : 'created on first run'}`,
      data.note
    ];
    setStatus(statusBox, 'ok', parts.join(' | '));
    document.getElementById('blenderPath').value = data.blenderPath || '';
  } catch (error) {
    setStatus(statusBox, 'error', error.message);
  }
}

modelInput.addEventListener('change', () => setFileLabel(modelInput, modelName));
textureInput.addEventListener('change', () => setFileLabel(textureInput, textureName));
animationsInput.addEventListener('change', () => setFileLabel(animationsInput, animationsName, true));

fillExampleBtn.addEventListener('click', () => {
  document.getElementById('outputFileName').value = 'character_bundle';
});

runForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  runBtn.disabled = true;
  downloadWrap.hidden = true;
  setStatus(resultState, 'working', 'Running Blender in the background. Try not to offend the computer while it works.');
  commandPreview.textContent = '-';
  stdoutBox.textContent = '-';
  stderrBox.textContent = '-';

  const rawName = document.getElementById('outputFileName').value.trim();

  if (!rawName) {
    setStatus(resultState, 'error', 'Write an output file name first.');
    runBtn.disabled = false;
    return;
  }

  const safeName = rawName.replace(/\.glb$/i, '');
  const outputFileName = safeName + '.glb';

  const formData = new FormData();
  formData.append('blenderPath', document.getElementById('blenderPath').value.trim());
  formData.append('outputFileName', outputFileName);

  if (!modelInput.files.length) {
    setStatus(resultState, 'error', 'Choose a character FBX first.');
    runBtn.disabled = false;
    return;
  }

  formData.append('modelFile', modelInput.files[0]);

  if (textureInput.files.length) {
    formData.append('textureFile', textureInput.files[0]);
  }

  for (const file of animationsInput.files) {
    formData.append('animationFiles', file);
  }

  try {
    const response = await fetch('/api/run-upload', { method: 'POST', body: formData });
    const data = await response.json();
    commandPreview.textContent = data.commandPreview || '-';
    stdoutBox.textContent = data.stdout || '-';
    stderrBox.textContent = data.stderr || '-';

    if (!response.ok || !data.ok) {
      setStatus(resultState, 'error', data.errors?.join(' ') || data.error || 'Something went wrong.');
      return;
    }

    setStatus(resultState, 'ok', data.note || 'Done.');
    downloadLink.href = data.downloadUrl;
    downloadLink.download = data.outputFileName || outputFileName;
    downloadLink.textContent = `Download ${data.outputFileName || outputFileName}`;
    downloadWrap.hidden = false;
  } catch (error) {
    setStatus(resultState, 'error', error.message);
  } finally {
    runBtn.disabled = false;
  }
});

loadStatus();